let x = document.getElementById("sel").length;
document.getElementById("show").innerHTML = x;
function setPadding() {
    const elem = document.getElementById("table1");
    elem.style.padding = "20px";
}

function changeBorder() {
    const elem = document.getElementById("table1");
    elem.style.border = "5px solid green";
}

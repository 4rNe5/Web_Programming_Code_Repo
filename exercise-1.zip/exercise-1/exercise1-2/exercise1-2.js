function countRadio() {
    let radios = document.getElementsByName("x");
    document.getElementById("show").innerHTML = radios.length;
}
